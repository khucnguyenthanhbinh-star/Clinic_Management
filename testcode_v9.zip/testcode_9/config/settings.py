APP_TITLE = "Hệ thống Quản lý Phòng khám"
WINDOW_SIZE = "1200x700"